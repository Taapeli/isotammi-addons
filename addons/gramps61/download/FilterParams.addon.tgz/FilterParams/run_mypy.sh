. ~/.python/venv_mypy/bin/activate

# MYPYPATH=/usr/lib/python3/dist-packages python -m mypy \

MYPYPATH=/home/kari/Downloads/software/gramps/gramps-5.2.0 python -m mypy \
	--follow-imports skip \
	--disallow-untyped-defs \
	FilterParams.py
	
