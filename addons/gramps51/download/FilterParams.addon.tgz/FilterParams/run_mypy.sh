. ~/.python/venv_mypy/bin/activate

MYPYPATH=/usr/lib/python3.10/dist-packages python -m mypy \
	--follow-imports skip \
	--disallow-untyped-defs \
	*.py
	
